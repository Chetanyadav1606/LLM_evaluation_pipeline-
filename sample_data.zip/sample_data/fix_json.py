import re
import json

def remove_trailing_commas(json_text):
    # Remove trailing commas before } or ]
    json_text = re.sub(r',\s*([}\]])', r'\1', json_text)
    return json_text

input_path = "context_vectors.json"
output_path = "context_vectors_clean.json"

with open(input_path, "r", encoding="utf-8") as f:
    raw = f.read()

cleaned = remove_trailing_commas(raw)

# Test if JSON becomes valid
try:
    parsed = json.loads(cleaned)
    print("✅ JSON fixed successfully!")
except json.JSONDecodeError as e:
    print("❌ Still invalid:", e)
    raise

with open(output_path, "w", encoding="utf-8") as f:
    f.write(cleaned)

print(f"Saved cleaned JSON to: {output_path}")
